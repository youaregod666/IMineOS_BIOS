print("your Running IMineOS FS")
print("Your only See msg on OpenOS")
print("Your Running BIOS 1.0 FS")
