
if require("Internet").run("https://raw.githubusercontent.com/youaregod666/mine/master/Installer/Main.lua") == nil then
  computer.shutdown(true)
end
